import { Component, OnInit } from '@angular/core';
import { CRMService } from '../shared/crm.service';

@Component({
  selector: 'app-acourseenquiry',
  templateUrl: './acourseenquiry.component.html',
  styleUrls: ['./acourseenquiry.component.css']
})
export class AcourseenquiryComponent implements OnInit {
  courses: any;

  constructor(private crmservice:CRMService) { }

  ngOnInit(): void {
    this.crmservice.getCourseEnquiry().subscribe((data)=>{
      this.courses=data;
      console.log("getCourses=",this.courses)
    });
  }

}

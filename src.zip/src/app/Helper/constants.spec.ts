import { Constants } from './constants';

describe('Constants', () => {
  it('should create an instance', () => {
    expect(new Constants()).toBeTruthy();
  });
});

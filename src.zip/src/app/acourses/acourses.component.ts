import { Component, OnInit } from '@angular/core';
import { CRMService } from '../shared/crm.service';

@Component({
  selector: 'app-acourses',
  templateUrl: './acourses.component.html',
  styleUrls: ['./acourses.component.css']
})
export class ACoursesComponent implements OnInit {
  courses:any;

  constructor(private crmservice:CRMService) { }

  ngOnInit(): void {
    this.crmservice.getCourses().subscribe((data)=>{
      this.courses=data;
      console.log("getCourses=",this.courses)
    });
  }

}

import { Courseenquiry } from './courseenquiry';

describe('Courseenquiry', () => {
  it('should create an instance', () => {
    expect(new Courseenquiry()).toBeTruthy();
  });
});

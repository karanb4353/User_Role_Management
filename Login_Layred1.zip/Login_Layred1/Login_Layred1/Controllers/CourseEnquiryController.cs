﻿using DomainLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryLayer;
using ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_Layred1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseEnquiryController : ControllerBase
    {
        private readonly ICourseEnquiry _course;
        private readonly AppDBContext _dbContext;
        public CourseEnquiryController(ICourseEnquiry course,AppDBContext dbContext)
        {
            this._course = course;
            this._dbContext = dbContext;
        }

        [HttpPost("AddEnquiry")]
        public IActionResult AddCourseEnquiry(CourseEnquiry course)
        {
            return Ok(this._course.AddEnquiry(course));
        }

        [HttpGet("AdminEnquiry")]
        public IActionResult GetAdminEnquiry()
        {

            List<Course> lcourse = _dbContext.Courses.ToList();
            List<CourseEnquiry> lcourseenq = _dbContext.CourseEnquiries.ToList();
            var result = from c in lcourse
                         join st in lcourseenq on c.courseId equals st.courseId
                         select new
                         {
                             coursename = c.courseName,
                             username = st.name

                         };
            return Ok(result);
        }
    }
}

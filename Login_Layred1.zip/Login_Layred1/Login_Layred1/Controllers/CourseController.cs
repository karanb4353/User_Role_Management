﻿using DomainLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_Layred1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourse _course;
        public CourseController(ICourse course)
        {
            this._course = course;
        }

        [HttpPost]
        public IActionResult AddCourse(Course course)
        {
            return Ok(this._course.AddCourse(course));
        }

        //AddCourse
        //GetAllCourses
        [HttpGet("GetAllCourses")]
        public IActionResult GetAllCourses()
        {
            var response = this._course.GetAllCourses();
            return Ok(response);
        }

        [HttpGet("{id:int}")]
        public IActionResult getSingleCourse(long id)
        {
            return Ok(this._course.getSingleCourse(id));
        }
    }
}

﻿using DomainLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public interface ICourseEnquiry
    {

        //AddEnquiry
        string AddEnquiry(CourseEnquiry courseenquiry);

        //GetEnquiry
        //List<CourseEnquiry> GetCourseEnquiries();

        //AdminEnquiry
       // public IEnumerable<CourseEnquiry> AdminEnquiry();
    }
}

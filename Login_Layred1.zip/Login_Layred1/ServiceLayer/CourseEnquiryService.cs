﻿using DomainLayer.Models;
using RepositoryLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class CourseEnquiryService : ICourseEnquiry
    {
        private readonly AppDBContext _dbContext;
        
        public CourseEnquiryService(AppDBContext dbContext)
        {
            this._dbContext = dbContext;
           
        }
        
        public string AddEnquiry(CourseEnquiry courseenquiry)
        {
            this._dbContext.CourseEnquiries.Add(courseenquiry);
            this._dbContext.SaveChanges();
            return ("Course Added");
        }

       

        //public List<CourseEnquiry> GetCourseEnquiries()
        //{
          //  return this._dbContext.CourseEnquiries.ToList();

        //}

        //public IEnumerable<CourseEnquiry> AdminEnquiry()
        //{
          //  List<Course> lcourse = _dbContext.Courses.ToList();
            //List<CourseEnquiry> lcourseenq = _dbContext.CourseEnquiries.ToList();
            //var result= from c in lcourse
              //           join st in lcourseenq on c.courseId equals st.courseId
                //         select new
                  //       {
                    //         coursename = c.courseName,
                      //       username = st.name

                        // };
          //  return (IEnumerable<CourseEnquiry>)result.ToList();
            


        
    }
}

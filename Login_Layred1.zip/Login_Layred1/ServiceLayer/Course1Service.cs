﻿using DomainLayer.Models;
using RepositoryLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class Course1Service : ICourse
    {
        private readonly AppDBContext _dbContext;
        public Course1Service(AppDBContext dbContext)
        {
            this._dbContext = dbContext;
        }
        //AddCourse
        public string AddCourse(Course course)
        {
            this._dbContext.Courses.Add(course);
            this._dbContext.SaveChanges();
            return ("Course Added");
            
        }
        //GetAllCourses
        public List<Course> GetAllCourses()
        {
            return this._dbContext.Courses.ToList();
            
        }

        public Course getSingleCourse(long id)
        {
            return this._dbContext.Courses.Where(x => x.courseId == id).FirstOrDefault();
        }
    }
}
